#!/bin/bash
# On récupère le premier paramètre est ont le met dans la variable d'environnement (pour indiquer à docker-compose le numéro de poste)
export NUM_INSTANCES=$1

# On créer nos trois machines S,G et D. On indique qu'on utilise les ports défini dans docker-compose.yml (--service-ports).
# On donne un nom à nos machines (--name) et on lance les conteneurs en arrière-plan (-d).
docker-compose run --service-ports --rm --name=S_$1 -d S
docker-compose run --service-ports --rm --name=D_$1 -d D
docker-compose run --service-ports --rm --name=G_$1 -d G