// Programme érit par Maxime HERVE le 4 Janvier 2022

#include <iostream>
#include <stdexcept>
#include <sys/types.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <vector>
#include <stdlib.h>

using namespace std;

string exec(const char *cmd)
{
    char buffer[128];
    std::string result = "";
    FILE *pipe = popen(cmd, "r");
    if (!pipe)
        throw std::runtime_error("popen() failed!");
    try
    {
        while (fgets(buffer, sizeof buffer, pipe) != NULL)
        {
            result += buffer;
        }
    }
    catch (...)
    {
        pclose(pipe);
        throw;
    }
    pclose(pipe);
    return result;
}

/*
Cette fonction permet de vérifier qu'une machine na pas déjà été créer, si elle n'est pas déjà créer on réserve la machine
*/
bool reservation(vector<int> &reserver, string num)
{
    bool res = true;
    int poste = stoi(num);

    if (find(reserver.begin(), reserver.end(), poste) != reserver.end())
        // La machine est déjà réservé
        res = false;
    else
        // On réserve la machine
        reserver.push_back(poste);

    return res;
}

void creer_machines(string p)
{
    int poste = stoi(p);

    // On créer les trois machines grâce à un script
    system(("cd /Users/maximeherve/Dropbox/Mac/Documents/Ptut/Docker_compose && ./script.sh " + to_string(poste)).c_str());
}

string donner_ports(string p, sockaddr_in hint)
{
    int poste = stoi(p);

    // On récupérer les ports des trois machines
    return "S_" + to_string(poste) + "=" + string(inet_ntoa(hint.sin_addr)) + ":" + exec(("docker port S_" + to_string(poste) + " | cut -b 19-24").c_str()) + "G_" + to_string(poste) + "=" + string(inet_ntoa(hint.sin_addr)) + ":" + exec(("docker port G_" + to_string(poste) + " | cut -b 19-24").c_str()) + "D_" + to_string(poste) + "=" + string(inet_ntoa(hint.sin_addr)) + ":" + exec(("docker port D_" + to_string(poste) + " | cut -b 19-24").c_str());
}

int main()
{
    // On suprimme les conteneurs inutilisé au démarrage du serveur
    system("docker system prune --force");

    // Create de socket
    // Création d'un socket IPV4
    int listening = socket(AF_INET, SOCK_STREAM, 0);
    if (listening == -1)
    {
        cerr << "can't create socket" << endl;
        return -1;
    }

    // Bind a socket to IP/Port
    sockaddr_in hint;
    hint.sin_family = AF_INET;

    // Port de connexion : 55000
    hint.sin_port = htons(55000);

    // Réservation du port
    inet_pton(AF_INET, "0.0.0.0", &hint.sin_addr);
    if (bind(listening, (struct sockaddr *)&hint, sizeof(hint)) == -1)
    {
        cerr << "can't bind address" << endl;
        return -2;
    }

    // Écoute du port
    if (listen(listening, SOMAXCONN) == -1)
    {
        cerr << "can't listen" << endl;
        return -3;
    }

    // On accepte la connexion
    sockaddr_in client;
    socklen_t clientSize = sizeof(client);
    char host[NI_MAXHOST];
    char svc[NI_MAXSERV];

    int clientSocket = accept(listening, (struct sockaddr *)&client, &clientSize);

    if (clientSocket == -1)
    {
        cerr << "problem with client connexion";
        return -4;
    }

    // On ferme l'écoute des clients
    close(listening);
    memset(host, 0, NI_MAXHOST);
    memset(svc, 0, NI_MAXSERV);

    // On récupère les infos sur le client
    int result = getnameinfo((struct sockaddr *)&client, sizeof(client), host, NI_MAXHOST, svc, NI_MAXSERV, 0);

    if (result)
    {
        cout << host << "connected on " << svc << endl;
    }
    else
    {
        inet_ntop(AF_INET, &client.sin_addr, host, NI_MAXHOST);
        cout << host << "connected on " << ntohs(client.sin_port) << endl;
    }

    vector<char> buf(5000);
    vector<int> reserver;
    bool etat = true;

    while (etat)
    {
        // Suppression des données dans le buffer
        memset(buf.data(), 0, 4096);

        // Attente de message
        switch (recv(clientSocket, buf.data(), buf.size(), 0))
        {
        case 0:
            cerr << "The client is disconnected" << endl;
            return -5;
        case -1:
            cerr << "There was a connexion issue" << endl;
            return -6;
        }

        // Si "poste" est trouvé dans le message (par exemple : poste 32)
        if (string(buf.begin(), buf.end()).find("poste") != string::npos)
        {
            if (isdigit(buf.at(6)) && isdigit(buf.at(7)))
            {
                // Vérification de la disponibilité
                if (reservation(reserver, string(buf.begin(), buf.end()).substr(6, 7)))
                {
                    // Si disponible création des machines et information du client
                    string message = "Création des machines...\n";
                    send(clientSocket, message.c_str(), message.size(), 0);
                    creer_machines(string(buf.begin(), buf.end()).substr(6, 7));

                    // On envoie les ports au client
                    message = donner_ports(string(buf.begin(), buf.end()).substr(6, 7), hint);
                    send(clientSocket, message.c_str(), message.size(), 0);
                }
                else
                {
                    // Si réservé, on informe le client
                    string message = "Le poste est déjà réservé\n";
                    send(clientSocket, message.c_str(), message.size(), 0);
                }
            }
            else
            {
                // Si n'est pas un nombre, on informe le client
                string message = "Voud devez fournir un numéro de poste, et non un caractère\n";
                send(clientSocket, message.c_str(), message.size(), 0);
            }
        }
        if (string(buf.begin(), buf.end()).find("exit") != string::npos)
        {
            etat = false;
        }
    }

    // Fermeture du socket
    close(clientSocket);

    return 0;
}