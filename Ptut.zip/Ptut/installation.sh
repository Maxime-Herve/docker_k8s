#!/bin/bash -ex
# Ce programme permet de connecter la machine au réseau et au serveur proxy
# Il permet aussi d'installer Docket et Kubernetes

CP_USB () {
    if [[ $(pwd ${BASH_SOURCE[0]})  == "/Media"* ]]
    then
        cp -R $(dirname ${BASH_SOURCE[0]}) $HOME;
        bash $($HOME"/"$(basename ${BASH_SOURCE[0]}))
    fi
    
}




# On relache l'adresse IP puis on en demande une nouvelle
dhclient -v -r;
dhclient -v;

# On demande à l'utilisateur de saisir son login
echo -n "Entrer votre login : ";
read -s LOGIN;

# On demande à l'utilisateur de saisir son mot de passe
echo -n "Entrer votre mot de passe : ";
read -s MDP;

# Importation des variables d'environnement pour mettre en place le serveur proxy
export HTTP_PROXY="http://$LOGIN:$MDP@10.254.0.254:3128";
export HTTPS_PROXY="http://$LOGIN:$MDP@10.254.0.254:3128";
export http_proxy="http://$LOGIN:$MDP@10.254.0.254:3128";
export https_proxy="http://$LOGIN:$MDP@10.254.0.254:3128";

#bash

# Installation de docker
sudo apt-get update -y;
sudo apt-get install ca-certificates -y;
sudo apt-get install curl -y;
sudo apt-get install gnupg -y;
sudo apt-get install lsb-release -y;

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/debian $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null;

sudo apt-cache madison docker-ce -y;
sudo apt install docker.io -y;
mkdir -p /etc/systemd/system/docker.service.d;

# Mise en place du proxy pour docker
echo "[Service] \

Environment="HTTP_PROXY=http://$LOGIN:$MDP@10.254.0.254:3128"
Environment="HTTPS_PROXY=http://$LOGIN:$MDP@10.254.0.254:3128"
Environment="NO_PROXY=localhost,127.0.0.1,::1"" > /etc/systemd/system/docker.service.d/override.conf;

sudo systemctl restart docker;
docker pull maximeherve/ptut:1.0;

# À faire : installation de Kubernetes