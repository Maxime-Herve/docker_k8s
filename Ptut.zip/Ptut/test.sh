#!/bin/bash

if [[ $(pwd ${BASH_SOURCE[0]})  == "/Media"* ]]
then
    cp -R $(dirname ${BASH_SOURCE[0]}) $HOME;
    bash $($HOME"/"$(basename ${BASH_SOURCE[0]}))
fi